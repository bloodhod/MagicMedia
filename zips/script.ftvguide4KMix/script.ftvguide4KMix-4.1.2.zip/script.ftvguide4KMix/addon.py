# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for Magic Media Guide Mix (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcaddon
import time
time = 2000 #in miliseconds
__addon__ = xbmcaddon.Addon('script.ftvguide4KMix')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
loadingline = 'Loading. Please Wait'
xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,loadingline, time, __icon__))

import gui
from utils import reset_playing

import os
import sys
import xbmcgui
import urllib2
import httplib
import urllib
import re

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguide4KMix/'
    )

inifolder = xbmc.translatePath(
    'special://home/userdata/addon_data/script.ftvguide4KMix/addons_'+custom_key+'.ini'
    )

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://magicmediaent.com/live/test/ftvtemp4kmix.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)

import urllib
urllib.urlretrieve (MAIN_URL+'addons.ini', TARGETFOLDER+'addons_'+custom_key+'.ini')
urllib.urlretrieve (MAIN_URL+'logo.db', TARGETFOLDER+'logo.db')

custom_mac = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_mac_1")
custom_login = xbmcaddon.Addon('plugin.video.stalker').getSetting("login_1")
custom_password = xbmcaddon.Addon('plugin.video.stalker').getSetting("password_1")
custom_server = xbmcaddon.Addon('plugin.video.stalker').getSetting("portal_server_1")
if custom_server == '5':
  custom_mac = '00:1A:78:'+custom_mac
  customportalserver = 'portal.iptvrocket.tv'
if custom_server == '6':
  custom_mac = '00:1A:79:'+custom_mac
  customportalserver = 'portal1.iptvrocket.tv'


TARGETFOLDERFile = TARGETFOLDER+'addons_'+custom_key+'.ini'

# Read in the file
filedata = None
with open(TARGETFOLDERFile, 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('123456789123', custom_login)

# Write the file out again
with open(TARGETFOLDERFile, 'w') as file:
  file.write(filedata)

#custom_mac = "00:1A:78:"+custom_mac
custom_mac = urllib.quote_plus(custom_mac)
# Read in the file
filedata = None
with open(TARGETFOLDERFile, 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('00%3A11%3A22%3A33%3A44%3A55', custom_mac)

# Write the file out again
with open(TARGETFOLDERFile, 'w') as file:
  file.write(filedata)

# Read in the file
filedata = None
with open(TARGETFOLDERFile, 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('portal.iptvrocket.tv', customportalserver)

# Write the file out again
with open(TARGETFOLDERFile, 'w') as file:
  file.write(filedata)

registermessage1 = "Magic Media is not activated"
registermessage2 = "Activate Magic Media is located on Power submenu. See How to for Activation instructions."

line1 = 'Magic Media Cloud Connection Opened!'
failedline = 'Magic Media 700+ Channels Live TV � English Guide � Espanol Guia available now with $100/yr subscription (Box update required).'

httplib.HTTPConnection.debuglevel = 1
request = urllib2.Request('http://magicmediaent.com/live/test/ftvverify.php?key='+custom_key)
opener = urllib2.build_opener()
f = opener.open(request)
MAIN_URL = f.url

if MAIN_URL == 'http://magicmediaent.com/live/test/ftv/':
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
else:
  xbmcgui.Dialog().ok(__addonname__, registermessage1, registermessage2)
  sys.exit(0)

try:
    w = gui.TVGuide()
    w.doModal()
    del w

except:
    import sys
    import traceback as tb
    (etype, value, traceback) = sys.exc_info()
    tb.print_exception(etype, value, traceback)